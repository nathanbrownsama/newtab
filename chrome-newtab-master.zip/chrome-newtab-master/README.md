# Chrome Newtab
A simple new tab page replacement for Google Chrome.

<h3>Process to install in Google Chrome as extension : </h3>
<ul>
<li> Open Terminal</li>
<li> git clone https://github.com/kaissaroj/chrome-newtab.git </li>
<li> OR just download from Download Zip Option </li>
<li>Copy this link  <strong>chrome://extensions/</strong> and paste in Chrome</li>
<li>Enable Developer Mode and click <strong>Load unpacked extension</strong> button and upload the folder</li>
<li>Done.</li>
</ul>


![Alt text](https://i.imgflip.com/2ltm3v.jpg "Screen  Shot 1")
![Alt text](https://i.imgflip.com/2ltm22.jpg "Screen  Shot 2")

<h3>#Feel free to Contribute<h3>
